# TECHNOHACKS_TASK-2
Calculate summary statistics (mean, median, mode, standard deviation) for a dataset.
HERE i ve used titanic datestet to perform basic stats
